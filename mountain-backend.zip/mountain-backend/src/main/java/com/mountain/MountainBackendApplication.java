package com.mountain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MountainBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(MountainBackendApplication.class, args);
	}

}
